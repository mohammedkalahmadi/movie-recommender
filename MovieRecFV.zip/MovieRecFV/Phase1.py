
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
import numpy as np
file_path = "IMDb_All_Genres_etf_clean1.csv"
df = pd.read_csv(file_path)
# Use a simple style
sns.set_style("whitegrid")

# ------------------------------------------
# 1) Histogram – Rating Distribution
# ------------------------------------------
plt.figure(figsize=(10, 5))
sns.histplot(df['Rating'], bins=30, kde=True, color='blue')
plt.title("Distribution of Movie Ratings")
plt.xlabel("Rating")
plt.ylabel("Count")
plt.tight_layout()
plt.show()

# Text summary for ratings
rating_min = df['Rating'].min()
rating_max = df['Rating'].max()
rating_mean = df['Rating'].mean()
rating_median = df['Rating'].median()
rating_std = df['Rating'].std()

# Most common rating range (rough)
rating_rounded = df['Rating'].round(1)
most_common = rating_rounded.value_counts().idxmax()

print("\n--- Summary: Rating Distribution ---")
print(f"Total movies with ratings: {len(df)}")
print(f"Rating range: {rating_min:.1f} to {rating_max:.1f}")
print(f"Mean rating: {rating_mean:.2f}")
print(f"Median rating: {rating_median:.2f}")
print(f"Most common rating range: {most_common:.1f}")
print(f"Standard deviation: {rating_std:.2f}")

# ------------------------------------------
# 2) Boxplot – Release Year
# ------------------------------------------
plt.figure(figsize=(10, 5))
sns.boxplot(x=df['Year'], color='skyblue')
plt.title("Boxplot of Movie Release Years")
plt.xlabel("Year")
plt.tight_layout()
plt.show()

year_min = df['Year'].min()
year_max = df['Year'].max()
year_median = df['Year'].median()
q1 = df['Year'].quantile(0.25)
q3 = df['Year'].quantile(0.75)
iqr = q3 - q1

# Outliers (Tukey rule)
lower_bound = q1 - 1.5 * iqr
upper_bound = q3 + 1.5 * iqr
outliers = df[(df['Year'] < lower_bound) | (df['Year'] > upper_bound)]

print("\n--- Summary: Release Year Distribution ---")
print(f"Earliest movie: {year_min}")
print(f"Latest movie: {year_max}")
print(f"Median year: {int(year_median)}")
print(f"Q1 (25%): {int(q1)}")
print(f"Q3 (75%): {int(q3)}")
print(f"IQR: {int(iqr)}")
print(f"Number of outliers detected: {len(outliers)}")

# ------------------------------------------
# 3) Scatter Plot – Runtime vs Rating
# ------------------------------------------
plt.figure(figsize=(10, 5))
plt.scatter(df['Runtime(Mins)'], df['Rating'], alpha=0.4)
plt.title("Scatter Plot: Runtime vs Rating")
plt.xlabel("Runtime(Mins)")
plt.ylabel("Rating")
plt.tight_layout()
plt.show()

runtime_min = df['Runtime(Mins)'].min()
runtime_max = df['Runtime(Mins)'].max()
runtime_mean = df['Runtime(Mins)'].mean()
runtime_median = df['Runtime(Mins)'].median()

corr_cols = ['Year', 'Rating', 'Runtime(Mins)']
corr_matrix = df[corr_cols].corr()

plt.figure(figsize=(6, 5))
sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', vmin=-1, vmax=1,
            linewidths=0.5, square=True)
plt.title("Correlation Matrix")
plt.tight_layout()
plt.show()

# Text summary for correlation
# Exclude self-correlation (diagonal)
corr_values = []
for i in range(len(corr_cols)):
    for j in range(i + 1, len(corr_cols)):
        corr_values.append((corr_cols[i], corr_cols[j],
                            corr_matrix.iloc[i, j]))

# Find weakest and strongest correlation (by absolute value)
weak_pair = min(corr_values, key=lambda x: abs(x[2]))
strong_pair = max(corr_values, key=lambda x: abs(x[2]))

print("\n--- Summary: Correlation Analysis ---")
print(f"Attributes analyzed: {', '.join(corr_cols)}")
print(f"Strongest correlation (excluding self-correlation): "
      f"{strong_pair[0]} <-> {strong_pair[1]}: {strong_pair[2]:.3f}")
print(f"Weakest correlation (excluding self-correlation): "
      f"{weak_pair[0]} <-> {weak_pair[1]}: {weak_pair[2]:.3f}")