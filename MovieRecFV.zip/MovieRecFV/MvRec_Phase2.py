import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.cluster import KMeans
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import silhouette_score
# Load and Clean
file_path = "IMDb_All_Genres_etf_clean1.csv"
df = pd.read_csv(file_path)

# Filter columns and handle missing values
df = df[['Movie_Title', 'Year', 'Rating', 'Runtime(Mins)', 'main_genre', 'side_genre']].copy()
df.fillna({
    'Movie_Title': '', 'main_genre': '', 'side_genre': '',
    'Rating': df['Rating'].mean(), 'Runtime(Mins)': df['Runtime(Mins)'].mean(),
    'Year': df['Year'].median()
}, inplace=True)

# Prepare features
df['text_data'] = (df['main_genre'] + ' ' + df['side_genre']).astype(str)
text_matrix = CountVectorizer().fit_transform(df['text_data'])
num_scaled = MinMaxScaler().fit_transform(df[['Rating', 'Runtime(Mins)']])
X = np.hstack([text_matrix.toarray(), num_scaled])

# Train Model
n_clusters = 180
kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
df['cluster_id'] = kmeans.fit_predict(X)
print(f"Model trained. Silhouette Score: {silhouette_score(X, df['cluster_id']):.4f}")

# Recommendation Function
def recommend_movie(user_input, top_n=5):
    # Find movie
    matches = df[df['Movie_Title'].str.contains(user_input, case=False, na=False)]
    if matches.empty:
        print(f"Movie '{user_input}' not found.")
        return

    # Select best match
    exact = matches[matches['Movie_Title'].str.lower() == user_input.lower()]
    movie = exact.iloc[0] if not exact.empty else matches.loc[matches['Movie_Title'].str.len().idxmin()]

    # Print Selected Movie
    print(f"\n> Selected: {movie['Movie_Title']} ({int(movie['Year'])}) | {movie['main_genre']} | Rating: {movie['Rating']}")

    # Get recommendations
    cluster_movies = df[(df['cluster_id'] == movie['cluster_id']) & (df.index != movie.name)]
    
    if cluster_movies.empty:
        print("  No similar movies found.")
        return

    # Sort by rating and print
    recs = cluster_movies.sort_values(by='Rating', ascending=False).head(top_n)

    for _, row in recs.iterrows():
        # Clean Output: Title (Year) | Genre | Rating
        print(f"  - {row['Movie_Title']} ({int(row['Year'])}) | {row['main_genre']}, {row['side_genre']} | {row['Rating']:.1f}")

# Save Data
df.to_csv("clustered_movies.csv", index=False)
print("clustered_movies.csv Saved.")
# Test Output
print("\n--- Testing Recommendations ---")
recommend_movie("The Dark Knight")   # Action
recommend_movie("Toy Story")         # Animation
recommend_movie("The Big Lebowski")  # Comedy